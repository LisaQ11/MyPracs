#ifndef NANOVIRUS_H_INCLUDED
#define NANOVIRUS_H_INCLUDED


#include <string>

using namespace std;

namespace NanoVirusSpace
{
    enum StatusCode
    {
        SUCCESS,
        ERROR_CMD_COUNT,
        ERROR_CONVERSION
    };
     enum DECISION
    {
        MOVE = 1,
        REPLICATE = 2,
        KILL = 3
    };

    enum GameEntity
    {
        SPACE,
        TUMOROUS,
        WHITECELL,
        REDCELL,
        NANOVIRUS
    };

     enum Direction
    {
        NORTH,
        NORTH_EAST,
        EAST,
        SOUTH_EAST,
        SOUTH,
        SOUTH_WEST,
        WEST,
        NORTH_WEST
    };

    typedef int** GameArray;
    struct GameWorld
    {
        GameArray aryWorld;
        int intRows;
        int intCols;
    };

    const char ARY_SYMBOLS[] ={'.','t','w','r','8'};
    const int CMD_ARG_COUNT =7;

    GameWorld makeWorld(int intRows, int intCols, int intNumVirus, int TumourChance, int RedChance, int WhiteChance);
    void showWorld(GameWorld recWorld);
    void freeWorld(GameWorld& recWorld);
    void updateWorld(GameWorld& recWorld);
    int rangedRandom(int intMin, int intMax);
    int tumorDecision();
    int convertToInt(string strNumber);
}

#endif // NANOVIRUS_H_INCLUDED
