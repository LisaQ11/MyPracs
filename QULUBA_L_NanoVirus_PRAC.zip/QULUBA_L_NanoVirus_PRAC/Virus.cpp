#include "NanoVirus.h"

#include <cstdlib>
#include <iostream>
#include <sstream>

using namespace std;

namespace NanoVirusSpace
{
    int rangedRandom(int intMin, int intMax)
    {
        int intRange = intMax - intMin + 1;
        return rand() % intRange + intMin;
    }

    int convertToInt(string strNumber)
    {
        stringstream ssConv;
        ssConv << strNumber;
        int intNumber = 0;
        ssConv >> intNumber;
        if(ssConv.fail())
        {
            cerr << "Unable to convert " << strNumber << endl;
            exit(ERROR_CONVERSION);
        }

        return intNumber;
    }

    bool isInWorld(GameWorld recWorld, int intRow, int intCol)
    {
        if(intRow < 0) return false;
        if(intCol < 0) return false;
        if(intRow >= recWorld.intRows) return false;
        if(intCol >= recWorld.intCols) return false;

        return true;
    }





    GameWorld makeWorld(int intRows, int intCols, int intNumVirus, int TumourChance, int RedChance, int WhiteChance)
    {
        GameWorld recWorld;
        recWorld.intRows = intRows;
        recWorld.intCols = intCols;

        recWorld.aryWorld = new int*[recWorld.intRows];
        for(int r = 0; r < recWorld.intRows; r++)
        {
            recWorld.aryWorld[r] = new int[recWorld.intCols];
            for(int c = 0; c < recWorld.intCols; c++)
            {
                recWorld.aryWorld[r][c] = SPACE;
            }
        }

        int intNumPlaced = 0;
        while(intNumPlaced < intNumVirus)
        {
            int intWR = rangedRandom(0, recWorld.intRows - 1);
            int intWC = rangedRandom(0, recWorld.intCols - 1);
            if(recWorld.aryWorld[intWR][intWC] == SPACE)
            {
                recWorld.aryWorld[intWR][intWC] = NANOVIRUS;
                intNumPlaced++;
            }
        }

        for(int r = 0; r < recWorld.intRows; r++)
        {
            for(int c = 0; c < recWorld.intCols; c++)
            {
                if(recWorld.aryWorld[r][c] == SPACE)
                {
                    int intRoll = rangedRandom(1, 100);
                    if(intRoll <= TumourChance)
                    {
                        recWorld.aryWorld[r][c] = TUMOROUS;
                    }
                }
            }
        }

        for(int r = 0; r < recWorld.intRows; r++)
        {
            for(int c = 0; c < recWorld.intCols; c++)
            {
                if(recWorld.aryWorld[r][c] == SPACE)
                {
                    int intRoll = rangedRandom(1, 100);
                    if(intRoll <= RedChance)
                    {
                        recWorld.aryWorld[r][c] = REDCELL;
                    }
                }
            }
        }

        for(int r = 0; r < recWorld.intRows; r++)
        {
            for(int c = 0; c < recWorld.intCols; c++)
            {
                if(recWorld.aryWorld[r][c] == SPACE)
                {
                    int intRoll = rangedRandom(1, 100);
                    if(intRoll <= WhiteChance)
                    {
                        recWorld.aryWorld[r][c] = WHITECELL;
                    }
                }
            }
        }



        return recWorld;
    }

     GameArray cloneWorld(GameWorld recWorld)
    {
        GameArray aryWorld = new int*[recWorld.intRows];
        for(int r = 0; r < recWorld.intRows; r++)
        {
            aryWorld[r] = new int[recWorld.intCols];
            for(int c = 0; c < recWorld.intCols; c++)
            {
                aryWorld[r][c] = recWorld.aryWorld[r][c];
            }
        }

        return aryWorld;
    }


void moveWalker(GameWorld recWorld, GameArray aryNewWorld, int intWR, int intWC)
    {
        int intDR = intWR;
        int intDC = intWC;

        const Direction ARY_DIRS[] = {
                                       NORTH,
                                       NORTH_EAST,
                                       EAST,
                                       SOUTH_EAST,
                                       SOUTH,
                                       SOUTH_WEST,
                                       WEST,
                                       NORTH_WEST
                                     };
        Direction eDir = ARY_DIRS[rangedRandom(0,7)];

        switch(eDir)
        {
            case NORTH:
                intDR--;
            break;

            case NORTH_EAST:
                intDR--;
                intDC++;
            break;

            case EAST:
                intDC++;
            break;

            case SOUTH_EAST:
                intDR++;
                intDC++;
            break;

            case SOUTH:
                intDR++;
            break;

            case SOUTH_WEST:
                intDR++;
                intDC--;
            break;

            case WEST:
                intDC--;
            break;

            case NORTH_WEST:
                intDR--;
                intDC--;
            break;
        }

        if(isInWorld(recWorld, intDR, intDC))
        {
            int RedCellOver =0;
            if(aryNewWorld[intDR][intDC] == SPACE)
            {

              if(aryNewWorld[intDR][intDC] != TUMOROUS && aryNewWorld[intDR][intDC] != NANOVIRUS)
                {
                    aryNewWorld[intWR][intWC] = SPACE;
                    aryNewWorld[intDR][intDC] = TUMOROUS;
                }
            }
            else if(aryNewWorld[intDR][intDC] == REDCELL)
            {
                 aryNewWorld[intDR][intDC] = TUMOROUS;
            }

              int counter =0;

                for(int r = 0; r < recWorld.intRows; r++)
                {
                    recWorld.aryWorld[r] = new int[recWorld.intCols];

                    for(int c = 0; c < recWorld.intCols; c++)
                    {
                        if(recWorld.aryWorld[r][c] == REDCELL)
                        {
                            counter++;
                        }

                    }
                }
                if(counter==0 && recWorld.aryWorld[intDR][intDC] == WHITECELL)
                {
                   aryNewWorld[intDR][intDC] = TUMOROUS;
                }
        }
    }
    int tumorDecision(){
        int random = rangedRandom(1,3);
        switch(random){
        case 1:
            return MOVE;
            break;
            case 2:
            return REPLICATE;
            break;
            case 3:
            return KILL;
            break;
        }
    }

    void updateWorld(GameWorld& recWorld)
    {

        GameArray aryNewWorld = cloneWorld(recWorld);

        for(int r = 0; r < recWorld.intRows; r++)
        {
            for(int c = 0; c < recWorld.intCols; c++)
            {
                if(recWorld.aryWorld[r][c] == TUMOROUS)
                {
                    moveWalker(recWorld, aryNewWorld, r, c);
                }
            }
        }
        freeWorld(recWorld);
        recWorld.aryWorld = aryNewWorld;
    }



    void showWorld(GameWorld recWorld)
    {

        system("cls");
        for(int r = 0; r < recWorld.intRows; r++)
        {
            for(int c = 0; c < recWorld.intCols; c++)
            {
                cout << ARY_SYMBOLS[recWorld.aryWorld[r][c]] << ' ';
            }
            cout << endl;
        }
    }




    void freeWorld(GameWorld& recWorld)
    {
        for(int r = 0; r < recWorld.intRows; r++)
        {
            delete [] recWorld.aryWorld[r];
        }

        delete [] recWorld.aryWorld;
       recWorld.aryWorld = 0;
    }



}
