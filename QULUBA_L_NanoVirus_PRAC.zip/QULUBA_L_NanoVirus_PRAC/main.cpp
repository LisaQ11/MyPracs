#include <cstdlib>
#include <ctime>
#include <iostream>
#include "NanoVirus.h"

using namespace std;
using namespace NanoVirusSpace;

int main(int argc, char** argv)
{

     srand(time(0));

    if(argc != CMD_ARG_COUNT)
    {
        cerr << argv[0] << " NUM_ROWS NUM_COLS NUM_NANO TUMOUR_CHANCE RED_CHANCE WHITE_CHANCE" << endl;
        exit(CMD_ARG_COUNT);
    }

    int intRows = convertToInt(argv[1]);
    int intCols = convertToInt(argv[2]);
    int intNumNano = convertToInt(argv[3]);
    int TumourChance = convertToInt(argv[4]);
    int RedChance = convertToInt(argv[5]);
    int WhiteChance = convertToInt(argv[6]);

    GameWorld recWorld = makeWorld(intRows, intCols,intNumNano, TumourChance, RedChance, WhiteChance);
    bool blnContinue = true;
    do
    {

        showWorld(recWorld);
        cout << "Continue Y/N: ";
        char chChoice = '\0';
        cin >> chChoice;

        switch(chChoice)
        {
            case 'y':
            case 'Y':
                 updateWorld(recWorld);
            break;

            case 'n':
            case 'N':
                blnContinue = false;
            break;

            default:
                cerr << "Invalid choice " << chChoice << endl;
                system("pause");
        }
    } while(blnContinue);


    //freeWorld(recWorld);

    return SUCCESS;
}
